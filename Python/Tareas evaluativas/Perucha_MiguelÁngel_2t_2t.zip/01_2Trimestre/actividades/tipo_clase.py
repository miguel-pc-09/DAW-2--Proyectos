from enum import Enum

# Tipos de clases/actividades que existen en el centro.
class TipoClase(Enum):
    YOGA = 1
    PILATES = 2
    ZUMBA = 3
    SPINNING = 4
