# Sirve para que Python trate esta carpeta como un "paquete"
# y podamos importar así: from actividades.actividad import Actividad