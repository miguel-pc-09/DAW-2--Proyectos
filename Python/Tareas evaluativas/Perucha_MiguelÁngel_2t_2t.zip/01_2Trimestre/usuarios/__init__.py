# Sirve para que Python trate esta carpeta como un "paquete"
# y podamos importar así: from usuarios.cliente import Cliente