from enum import Enum

# Especialidades del entrenador.
class TipoEspecialidad(Enum):
    YOGA = 1
    CROSSFIT = 2
    MUSCULACION = 3
    PILATES = 4
