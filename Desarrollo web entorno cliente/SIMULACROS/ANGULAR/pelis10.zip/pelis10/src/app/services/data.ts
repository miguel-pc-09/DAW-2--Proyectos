import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class Data {
  url = 'https://api.sampleapis.com/movies/animation';
  constructor(private http: HttpClient) {}

  getAllPeliculas(): Observable<any> {
    return this.http.get(this.url);
  }
}
